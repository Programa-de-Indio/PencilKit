import UIKit
import PencilKit

public class MyViewController: UIViewController{
    
    let canvasView = PKCanvasView(frame: CGRect(x:0, y:0, width: 100, height: 100))
    
    override public func viewDidLoad() {
        view.backgroundColor = #colorLiteral(red: 0.9764705882352941, green: 0.8509803921568627, blue: 0.5490196078431373, alpha: 1.0)
        view.addSubview(canvasView)
        canvasView.translatesAutoresizingMaskIntoConstraints = false
        
        canvasView.isOpaque = false
        canvasView.backgroundColor = .clear
        
        NSLayoutConstraint.activate([
            canvasView.topAnchor.constraint(equalTo: view.topAnchor),
            canvasView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            canvasView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            canvasView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard let window = view.window, let toolPicker = PKToolPicker.shared(for: window) else { return }
        toolPicker.setVisible(true, forFirstResponder: canvasView)
        toolPicker.addObserver(canvasView)
        canvasView.becomeFirstResponder()
    }
}
